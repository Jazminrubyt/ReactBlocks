const Header = () => {
    return (
    <div className="top-nav">Header</div>
    )
}

export default Header