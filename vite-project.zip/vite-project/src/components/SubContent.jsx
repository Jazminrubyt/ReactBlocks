const SubContent = () => {
    return (
    <div className="sub-content">SubContent
    </div>
    )
}

export default SubContent