const Navigation = () => {
    return (
        <div className="side-nav">Navigation</div>
    )
}

export default Navigation